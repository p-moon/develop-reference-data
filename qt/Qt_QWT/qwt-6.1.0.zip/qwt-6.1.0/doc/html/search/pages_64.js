var searchData=
[
  ['dials_2c_20compasses_2c_20knobs_2c_20wheels_2c_20sliders_2c_20thermos',['Dials, Compasses, Knobs, Wheels, Sliders, Thermos',['../controlscreenshots.html',1,'']]]
];
