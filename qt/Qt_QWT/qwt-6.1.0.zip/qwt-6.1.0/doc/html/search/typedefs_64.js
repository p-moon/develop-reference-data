var searchData=
[
  ['discardflags',['DiscardFlags',['../class_qwt_plot_renderer.html#aa61638c08ef926c0148dd12c9f830b2d',1,'QwtPlotRenderer']]],
  ['displaymodes',['DisplayModes',['../class_qwt_plot_spectrogram.html#a245a6d1281abe84d177d61be0698db55',1,'QwtPlotSpectrogram']]]
];
