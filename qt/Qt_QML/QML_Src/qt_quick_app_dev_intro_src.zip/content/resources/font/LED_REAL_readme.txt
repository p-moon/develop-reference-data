Font: LED Real (led_real.ttf)
Created By: Matthew Welch
E-Mail: daffy-duck@worldnet.att.net
Web Address: http://home.att.net/~daffy-duck
             (PGP public key available here)

LED Real, like all of my fonts, is free.  You can use it for most
personal or business uses you'd like, and I ask for no money.  I
would, however, like to hear from you.  If you use my fonts for
something please send me a postcard or e-mail letting me know how
you used it.  Send me a copy if you can or let me know where I can
find your work.

You may use this font for graphical or printed work, but you may not
sell it or include it in a collection of fonts (on CD or otherwise)
being sold. You can redistribute this font as long as you charge
nothing to receive it. If you redistribute it include this text file
with it as is (without modifications).

If you use this font for commercial purposes please credit me in
at least some little way.

About the font:

Unlike most LED/LCD style fonts mine could be recreated with an
actual LED.  I created this font working from memories of the good
old Speak and Spell display.  Since I don't have an actual Speak
and Spell to work from I had to just do as well as I could in its
spirit.  Be warned that some characters look just like others.  The
( and the <, for instance.  Also C and [.  Most of these will be
pretty clear in context.  To see all the sections of the LED "lit
up" at once use character 127 (hold down alt and type 0127 on the
numeric keypad).  This font is, of course, monospaced.

