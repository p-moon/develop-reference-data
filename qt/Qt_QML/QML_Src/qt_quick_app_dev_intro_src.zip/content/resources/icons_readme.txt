Important information about icons
==================================

This application uses weather condition bitmaps of the Oxygen theme from the yaWP project ("yawp", http://yawp.sourceforge.net/). yaWP is a very popular weather widget used in the KDE desktop. Please check the project web site for further details.

The other UI icons originate from the KDE project

